package Plugins::MusicArtistInfo::Lyrics::LRCLib;

use strict;

use List::Util qw(min max);
use URI::Escape qw(uri_escape_utf8);
use Time::HiRes;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

# LRCLib used to hang responses, therefore we used a proxy. But that seems to no longer be needed
use constant BASE_URL => 'https://lrclib.net/api/';
# use constant BASE_URL_PROXIED => 'http://localhost:8787/music/LRCLibProxy/';
use constant BASE_URL_PROXIED => 'https://api.lms-community.org/music/LRCLibProxy/';
use constant GET_URL => 'get?artist_name=%s&track_name=%s';
use constant SEARCH_URL => 'search?artist_name=%s&track_name=%s';

# if we have different durations in a search result, accept a maximum difference of X seconds
use constant MAX_DURATION_DIFF => 5;
use constant MAX_LAG_BEFORE_PROXYING_SECS => 5;
use constant PROXYING_PERIOD => 60 * 60;    # reset proxying after an hour, to see whether the situation has improved
use constant REQUESTS_TO_AVERAGE => 5;      # number of requests to average response time over before deciding to proxy

my $log = logger('plugin.musicartistinfo');
my $prefs = preferences('plugin.musicartistinfo');
my $useLRCProxy = 0;
my $instrumentalString;
my $avgResponseTimeInSecs = 1;


sub _buildQueryParameters {
	my ($urlTemplate, $args) = @_;

	my $url = sprintf($urlTemplate, uri_escape_utf8($args->{artist}), uri_escape_utf8($args->{title}));

	$url .= '&album_name=' . uri_escape_utf8($args->{album}) if $args->{album};
	$url .= '&duration=' . uri_escape_utf8($args->{duration}) if $args->{duration};

	return $url;
}


sub getLyrics {
	my ( $class, $args, $cb ) = @_;

	return $cb->() unless $args->{artist} && $args->{title};

	_call(
		_buildQueryParameters(GET_URL, $args),
		sub {
			my $result = shift;

			if ($result && ref $result && ($result->{plainLyrics} || $result->{syncedLyrics} || $result->{instrumental})) {
				$instrumentalString ||= Slim::Utils::Strings::string('PLUGIN_MUSICARTISTINFO_INSTRUMENTAL');

				return $cb->({
					song => $args->{title},
					artist => $args->{artist},
					lyrics => $result->{syncedLyrics} || $result->{plainLyrics} || $instrumentalString,
				});
			}

			$cb->();
		}
	);

	return;
}


sub searchLyrics {
	my ( $class, $args, $cb ) = @_;

	return $cb->() unless $args->{artist} && $args->{title};

	_call(
		_buildQueryParameters(SEARCH_URL, $args),
		sub {
			my $result = shift;

			if ($result && ref $result && ref $result eq 'ARRAY' && scalar @$result) {
				my $artist = lc($args->{artist});
				my $track  = lc($args->{title});
				my $duration = $args->{duration};

				$result = [ grep {
					$_ && ref $_ && ($_->{plainLyrics} || $_->{syncedLyrics} || $_->{instrumental})
				} @$result ];

				my $useSynced;

				if ($duration) {
					# if we have a duration, sort candidates by closest duration
					$result = [ sort {
						abs($a->{duration} - $args->{duration}) <=> abs($b->{duration} - $args->{duration})
					} @$result ];
				}
				else {
					# without a duration given, only use synced lyrics if all candidates have similar durations
					my ($min, $max);
					foreach (@$result) {
						$min ||= $_->{duration};
						$max ||= $_->{duration};
						$min = min($min, $_->{duration});
						$max = max($max, $_->{duration});
					}
					$useSynced = (($max - $min) <= MAX_DURATION_DIFF);
				}

				my ($lyrics) = grep {
					lc($_->{artistName}) eq $artist && lc($_->{trackName}) eq $track;
				} @$result;

				if (!$lyrics) {
					($lyrics) = grep {
						$_->{artist} =~ /\Q$artist\E/i && $_->{trackName} =~ /\Q$track\E/i;
					} @$result;
				}

				if ($duration && $lyrics) {
					$useSynced = abs($lyrics->{duration} - $duration) <= MAX_DURATION_DIFF;
				}

				$instrumentalString ||= Slim::Utils::Strings::string('PLUGIN_MUSICARTISTINFO_INSTRUMENTAL');

				return $cb->({
					song => $lyrics->{title},
					artist => $lyrics->{artist},
					lyrics => ($useSynced && $lyrics->{syncedLyrics}) || $lyrics->{plainLyrics} || $instrumentalString,
				}) if $lyrics;
			}

			$cb->();
		}
	);

	return;
}

sub _call {
	my ($url, $cb) = @_;

	my $startTime = Time::HiRes::time();

	__call(
		$url,
		sub {
			my ($result) = @_;

			my $responseTime = Time::HiRes::time() - $startTime;
			$avgResponseTimeInSecs = ($avgResponseTimeInSecs * (REQUESTS_TO_AVERAGE - 1) + $responseTime) / REQUESTS_TO_AVERAGE;

			main::INFOLOG && $log->is_info && $log->info(sprintf('Response time: %.3fs (average: %.3fs)', $responseTime, $avgResponseTimeInSecs));

			if (!_useLRCProxy() && $responseTime > MAX_LAG_BEFORE_PROXYING_SECS) {
				main::INFOLOG && $log->is_info && $log->info("LRCLib is taking a long time to respond - enabling proxying");
				__PACKAGE__->enableProxying();
			}

			$cb->($result);
		},{
			timeout => 5,
			cache => 1,
			expires => 86400,
			ignoreError => [404]
		}
	);
}

sub __call {
	my $url = shift;

	if (_useLRCProxy()) {
		require Plugins::MusicArtistInfo::API;
		Plugins::MusicArtistInfo::API::_call(BASE_URL_PROXIED . $url, @_);
	}
	else {
		Plugins::MusicArtistInfo::Common->call(BASE_URL . $url, @_);
	}
}

sub enableProxying {
	my $class = shift;
	$useLRCProxy = 1;

	# but don't proxy forever...
	Slim::Utils::Timers::killTimers($class, \&_resetProxying);
	Slim::Utils::Timers::setTimer($class, time() + PROXYING_PERIOD, \&_resetProxying);
}

sub _resetProxying {
	$useLRCProxy = 0;
	main::INFOLOG && $log->is_info && $log->info("LRCLib proxying disabled again");
}

sub _useLRCProxy {
	return $useLRCProxy || $prefs->get('forceLRCProxy');
}

1;